<?php
namespace CoxAndCox\MarketingPreferences;

class SubscribeTest extends \PHPUnit_Framework_TestCase
{
}
