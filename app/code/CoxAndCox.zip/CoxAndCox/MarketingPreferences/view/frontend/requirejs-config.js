var config = {
    paths: {
        'newsletterInput': 'CoxAndCox_MarketingPreferences/js/newsletter-input',
        'newsletterSubmit': 'CoxAndCox_MarketingPreferences/js/newsletter-submit'
    }
};
