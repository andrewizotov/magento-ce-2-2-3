define(
    [
        'ko',
        'uiComponent',
        'newsletterSubmit',
        'jquery'
    ],
    function (ko, Component, Newsletter, $) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'CoxAndCox_MarketingPreferences/checkout/newsletter-signup'
            },

            newsletterChecked: ko.observable(true),
            thirdParty: ko.observable(false),
            postalMailings: ko.observable(false),

            check: function () {
                this.newsletterChecked(true);
                Newsletter.newsletterUpdate(true);
            },

            uncheck: function () {
                this.newsletterChecked(false);
                Newsletter.newsletterUpdate(false);
            },

            thirdPartyUpdate: function () {
                Newsletter.thirdPartyUpdate(this.thirdParty());
                return true;
            },

            postalMailingsUpdate: function () {
                Newsletter.postalMailingsUpdate(this.postalMailings());
                return true;
            },

            thirdPartyLoad: function (target, viewModel) {
                var self = this;
                $.ajax({
                    url: Newsletter.url,
                    data: {
                        type_mailing: 'thirdParty'
                    },
                    success : function(data){
                        if (data['third_party'] == 1) {
                            $(target).prop('checked',true);
                        } else {
                            $(target).prop('checked', false);
                        }

                    },
                    type: 'POST'
                });
            },

            postalMailingsLoad: function (target, viewModel) {
                var self = this;
                $.ajax({
                    url: Newsletter.url,
                    data: {
                        type_mailing: 'postalMailings'
                    },
                    success : function(data){
                        if (data['postal_mailings'] == 1) {
                            $(target).prop('checked',true);
                        } else {
                            $(target).prop('checked', false);
                        }

                    },
                    type: 'POST'
                });
            }
        });
    }
);
